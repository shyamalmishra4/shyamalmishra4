:mod:`gidgethub.tornado` --- Tornado support
=================================================

.. module:: gidgethub.tornado

.. class:: GitHubAPI(requester, *, oauth_token=None, cache=None)

    An implementation of :class:`gidgethub.abc.GitHubAPI` using
    `Tornado <http://www.tornadoweb.org/>`_.
